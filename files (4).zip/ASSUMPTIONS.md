# Assumptions

The Round 2 brief says teams are *"encouraged to make your own reasonable assumptions, state
them clearly, and design a solution that would generalize for broader adoption."* This file is
that statement. Every assumption below is a design input, not a hidden default — where an
assumption materially constrains the solution, we say what would change if it were relaxed.

---

## 1. The organisation we are designing for

We do not have access to a real company's proprietary data, so we designed against a
representative fictional organisation and generated a dataset that reproduces its dynamics.

| | Assumption | Why it matters |
|---|---|---|
| Company | **NovaCare Consumer Pvt Ltd** — mid-size Indian D2C/FMCG skincare brand | Consumer goods gives natural price/volume/mix interaction, which is where naive KPI tooling fails |
| Scale | ₹48.4 Cr over 18 months, 140,881 order lines | Large enough for statistics to be meaningful, small enough to run on a laptop |
| Structure | 4 regions × 2 channels (Retail, Ecom) × 10 SKUs × 24 distributors per region | Gives a four-level attribution tree: region → channel → SKU → account |
| History | 1 Jan 2025 – 30 Jun 2026 | 18 months = enough for one full seasonal cycle plus a holdout period |
| Users | ~40 KPI owners, ~6 analysts | Sets realistic concurrency and therefore cost-per-insight targets |

**If relaxed:** at enterprise scale (millions of order lines) the contribution bridge would move
from in-memory pandas to pushdown SQL on the warehouse. The algorithm is unchanged; only the
execution engine differs. This is called out in the roadmap.

## 2. Data

- **Three sources with deliberately different grains and refresh cadences**, because the brief
  calls out *"different source-system refresh cadences, grains, data quality levels."*
  - `sales_orders` — order-line grain, daily 02:00 IST refresh, high trust
  - `weekly_ops` — week × region × channel grain, weekly Monday refresh, medium trust
  - `signals` — event grain, irregular/event-driven refresh, low trust
- **The weekly source cannot support day-level attribution.** The engine must widen its evidence
  window to whole weeks whenever it cites `weekly_ops`. This is enforced in the KPI contract
  rather than left to the model's discretion.
- **Unstructured text is qualitative only.** It may raise or lower confidence in a hypothesis that
  was quantitatively derived, but it may never *originate* a numeric claim. This is the single
  most important data rule in the system.
- **Data is synthetic but not arbitrary.** All randomness is drawn once for a base order book that
  is independent of any planted event; events are then applied as deterministic row-wise filters.
  Toggling an event off therefore reproduces the exact counterfactual, which gives us true
  contribution figures to score the engine against. We are not grading ourselves on vibes.

## 3. What "correct" means (ground truth)

Three scenarios are planted with known answers:

| Scenario | Movement vs counterfactual | True composition |
|---|---|---|
| West, Mar 2026 | −18.7% | distributor churn 34.1%, stockout 30.1%, competitor promo 27.6%, ~8% interaction |
| South, May 2026 | −17.7% | price test only — but marketing spend rose 50% and campaign notes are positive, so evidence is genuinely contradictory. **Correct behaviour is to abstain, not to guess.** |
| NC-BOOST-01, Jun 2026 | −35.4% | post-launch momentum loss on a SKU launched 2026-02-01. Correct behaviour is to cap confidence for insufficient history. |

Note the engine detects the West movement as −13.7% against its own trailing baseline, not
−18.7%. Those measure different things: a trailing baseline absorbs part of a change that began
before the period. We therefore evaluate on driver identification and rank order rather than on
shares.

We assume a correct system is one that recovers driver ranking and approximate contribution on
the first, abstains on the second, and self-limits on the third. Average accuracy alone would
reward a system that confidently guesses on scenario 2, which is precisely the failure mode the
brief warns about.

## 4. Regulatory and security posture

- **Jurisdiction: India, Digital Personal Data Protection Act 2023.** Chosen because our users and
  scenario are Indian. Consequences we design for:
  - Distributor and account identifiers are **business** entities, not natural persons, so they sit
    outside DPDP's personal-data scope. Free-text CRM/support notes *can* contain personal data, so
    the signal store is treated as the sensitive surface.
  - Purpose limitation: signals are ingested for root-cause explanation only, and the retrieved
    snippet plus its ID is logged, not the whole record.
  - We assume 24-month retention for analytic aggregates and 90-day retention for raw text
    snippets held in the vector index.
- **Row-level security by region, column-level security on margin.** A regional ops manager sees
  only their own region, and `gross_margin_pct` / `cogs` are withheld from regional roles and
  visible to analyst and finance roles. We assume entitlements come from the corporate IdP; in the
  prototype they are read from the `roles` block of the KPI contract.
- **Security is applied at query time, not in the UI.** Filtering only the display would leak data
  through the narrative and through telemetry. We assume the enforcement point must sit before the
  analytical layer.

## 5. LLM usage

- We assume the LLM is consumed **via API**, not self-hosted, so we cannot inspect internals and
  must treat it as an untrusted component at the boundary.
- **The LLM is never the source of quantitative truth.** It is used for exactly three jobs: parsing
  user intent into a structured query, rendering an already-computed evidence object into
  persona-appropriate prose, and phrasing the recommended action. Detection, decomposition,
  hypothesis testing and confidence scoring are fully deterministic.
- We assume a **numeric guard** is mandatory: after generation, every number in the narrative is
  extracted and checked against the computed evidence object, and the narrative is rejected if a
  number does not reconcile.
- Cost assumptions used in the telemetry panel are the published per-million-token rates for the
  model tier selected at runtime; we assume routine narratives can be served by a cheaper tier and
  only multi-driver contested cases escalate to a stronger one.

## 6. Latency and cost targets

| Path | Target | Rationale |
|---|---|---|
| Scheduled detection sweep | < 5 min for the full KPI × dimension grid | Runs nightly after the 02:00 load, so it is off the user's critical path |
| Insight open (cached) | < 2 s | Should feel like opening a dashboard |
| Insight open (cold, full diagnosis) | < 30 s | The alternative today is 2–3 days of analyst work |
| Cost per delivered insight | < ₹15 | Must stay well under the loaded cost of the analyst hours displaced |

## 7. Scope we deliberately did not build

Stated openly because the brief rewards distinguishing native, configured, custom-built and
integrated capability — and because unstated gaps read as oversights.

- **No warehouse integration.** We read CSVs. In production these are Databricks/Snowflake tables;
  the semantic contract is the seam that makes the swap mechanical.
- **No causal inference at all.** Every driver test is associational: step changes, z-scores,
  and excess-over-broad-decline. We do not run difference-in-differences or placebo tests, and
  we make no claim of causal identification. The engine reports contribution and evidence, and
  the confidence score reflects evidential strength, not causal proof. An earlier draft of this
  document claimed a difference-in-differences check; it was never implemented and the claim has
  been removed.
- **Feedback updates driver priors, it does not retrain a model.** Analyst verdicts adjust a stored
  weight that visibly reranks future hypotheses. A learned reranker is roadmap, not prototype.
- **No production auth.** Roles are selected in the sidebar to make the entitlement scenario
  demonstrable; the enforcement point is real, the identity source is stubbed.
