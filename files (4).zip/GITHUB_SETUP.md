# GitHub setup — exact steps

No command line needed. Everything here is done in the browser.

---

## Part 1 — Create the repo (one of you does this, 3 minutes)

Whoever creates it becomes the owner; the other gets added as a collaborator with equal
write access in Part 4.

1. Go to **github.com** and sign in.
2. Click the **+** in the top right → **New repository**.
3. Fill in:
   - **Repository name:** `causalloop`
   - **Description:** `KPI intelligence-to-action engine — Accenture Innovation Challenge 2026, Track 3`
   - **Public** ← required, the brief asks for a public repo
   - **Do NOT** tick "Add a README file" — we have our own
4. Click **Create repository**.

You'll land on a page of setup instructions. Ignore all of it. Look for the link
**"uploading an existing file"** in the middle of the page and click it.

---

## Part 2 — Upload the flat files (2 minutes)

Drag these 12 files into the upload box, all at once:

```
README.md
ASSUMPTIONS.md
FILE_GUIDE.md
SUBMISSION_CHECKLIST.md
GITHUB_SETUP.md
requirements.txt
generate_data.py
kpi_contract.yaml
demo_app.py
evaluate.py
causalloop_prototype.py
causalloop_evaluation.py
```

In the "Commit changes" box, write: `Governed KPI contract, dataset, prototype and evaluation`

Click **Commit changes**.

---

## Part 3 — Create the folders (5 minutes)

**GitHub has no "new folder" button.** You create a folder by typing a path in the filename box.
Typing `engine/detect.py` creates the `engine` folder and puts `detect.py` inside it.

For each file below, repeat this loop:

1. **Add file** (button, top right) → **Create new file**
2. In the filename box type the path exactly as shown
3. Open the corresponding file on your computer, select all, copy, paste into the big box
4. Scroll down, click **Commit changes**

Files to create this way:

| Type this filename | Paste the contents of |
|---|---|
| `engine/__init__.py` | *(leave empty — if GitHub refuses, type a single `#`)* |
| `engine/detect.py` | `detect.py` |
| `engine/crosskpi.py` | `crosskpi.py` |
| `engine/decompose.py` | `decompose.py` |
| `engine/diagnose.py` | `diagnose.py` |
| `narrative/__init__.py` | *(leave empty, or a single `#`)* |
| `narrative/render.py` | `render.py` |
| `data/ground_truth.json` | `ground_truth.json` |

**Do not upload the CSVs in `data/`.** They are about 15 MB and regenerate byte-for-byte from
`generate_data.py`. `ground_truth.json` is small and is evidence, so it stays.

---

## Part 4 — Add the second person (1 minute)

This gives you both full write access. GitHub does not have two "owners" of a personal
repository, but a collaborator with write access can do everything that matters here: push,
edit, merge, and manage files. That is what you want.

1. In the repo, click **Settings** (top bar, far right)
2. Left sidebar → **Collaborators**
3. Confirm your password if prompted
4. **Add people** → type the other person's GitHub username → select them → **Add**
5. They get an email invite and must **accept** it before their access is live

**If you want true joint ownership instead**, create a GitHub **Organisation** (free) and put the
repo there — both of you can then be organisation owners. For a two-person hackathon submission
this is more ceremony than it's worth, and judges only look at whether the repo is public.

---

## Part 5 — Check it (2 minutes)

Your repo should look like this:

```
causalloop/
├── README.md
├── ASSUMPTIONS.md
├── FILE_GUIDE.md
├── SUBMISSION_CHECKLIST.md
├── GITHUB_SETUP.md
├── requirements.txt
├── generate_data.py
├── kpi_contract.yaml
├── demo_app.py
├── evaluate.py
├── causalloop_prototype.py
├── causalloop_evaluation.py
├── engine/      __init__.py  detect.py  crosskpi.py  decompose.py  diagnose.py
├── narrative/   __init__.py  render.py
└── data/        ground_truth.json
```

Then check three things:

- The README renders on the front page with its tables intact
- `engine/` and `narrative/` show as folders with the right files inside
- Open the repo in a private/incognito window — if it loads while logged out, it is genuinely
  public

---

## Part 6 — Still to add before submitting

The brief requires the repo to contain a **demo video** and a **README**. The README is done.

- **Demo video:** record the prototype, upload to YouTube (unlisted is fine) or Google Drive
  (sharing set to "anyone with the link"), then add the link near the top of `README.md`.
- **Business proposal:** export to PDF and either upload it to the repo or link it from the
  README.

---

## Working together without clashing

You are both editing through the browser, so merge conflicts are unlikely but not impossible if
you edit the same file at the same time. Split ownership:

- **Mitanshi:** `engine/`, `narrative/`, `evaluate.py`, `demo_app.py`
- **Mudita:** the `.md` files, the proposal, the video link
- **`kpi_contract.yaml`:** shared — say so in chat before editing

If GitHub ever says the file changed since you started editing, refresh the page, re-copy your
change, and reapply it. Nothing is lost.
